package com.eaglefive.iotanyware.app;

import com.eaglefive.iotanyware.service.client.IotaClient;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;

public class IotaClientRunner {

	public static final int MSG_SUCCESS = 0;
	public static final int MSG_FAILURE = 1;

	public static void registerAccount(Handler handler, String email, String nickname, String password) {
		IClientRunner icr = new RegisterAccountRunner(handler, email, nickname, password);
		new Runner().execute(icr);
	}

	public static void login(Handler handler, String email, String password) {
		IClientRunner icr = new LoginRunner(handler, email, password);
		new Runner().execute(icr);
	}

	public static void getSANodeList(Handler handler, int msg) {
		IClientRunner icr = new GetSANodeListRunner(handler, msg);
		new Runner().execute(icr);
	}

	public static void registerSANode(Handler handler, int msg, String nodeid, String nickname, boolean virtual) {
		IClientRunner icr = new RegisterSANodeRunner(handler, msg, nodeid, nickname, virtual);
		new Runner().execute(icr);
	}

	public static void unregisterSANode(Handler handler, int msg, String nodeid) {
		IClientRunner icr = new UnregisterSANodeRunner(handler, msg, nodeid);
		new Runner().execute(icr);
	}

	public static void getClientHistory(Handler handler, int msg) {
		IClientRunner icr = new GetClientHistoryRunner(handler, msg);
		new Runner().execute(icr);
	}

	public static class Result {
		boolean result;
		Object obj;
		Result () {}
		Result (boolean result, Object obj) {
			this.result = result;
			this.obj = obj;
		}
	}

	private static class RegisterAccountRunner implements IClientRunner {
		Handler handler;
		String email;
		String nickname;
		String password;

		RegisterAccountRunner(Handler handler, String email, String nickname, String password) {
			this.handler = handler;
			this.email = email;
			this.nickname = nickname;
			this.password = password;
		}

		@Override
		public void run() {
			int msg;
			boolean ret = IotaClient.getServiceInterface().register(email, nickname, password);
			if (ret) {
				msg = MSG_SUCCESS;
			} else {
				msg = MSG_FAILURE;
			}
			handler.sendEmptyMessage(msg);
		}
	}

	private static class LoginRunner implements IClientRunner {
		Handler handler;
		String email;
		String password;

		LoginRunner(Handler handler, String email, String password) {
			this.handler = handler;
			this.email = email;
			this.password = password;
		}

		@Override
		public void run() {
			int msg;
			boolean ret = IotaClient.getServiceInterface().login(email, password);
			if (ret) {
				msg = MSG_SUCCESS;
			} else {
				msg = MSG_FAILURE;
			}
			handler.sendEmptyMessage(msg);
		}
	}

	private static class GetSANodeListRunner implements IClientRunner {
		Handler handler;
		int msg;

		GetSANodeListRunner(Handler handler, int msg) {
			this.handler = handler;
			this.msg = msg;
		}

		@Override
		public void run() {
			String nodeList = IotaClient.getServiceInterface().getSANodeList();

			if (nodeList != null && nodeList.length() > 0) {
				handler.removeMessages(msg);
				Message m = handler.obtainMessage(msg);
				m.obj = nodeList;
				handler.sendMessage(m);
			}
		}
	}

	private static class RegisterSANodeRunner implements IClientRunner {
		Handler handler;
		int msg;
		String nodeid;
		String nickname;
		boolean virtual;

		RegisterSANodeRunner(Handler handler, int msg, String nodeid, String nickname, boolean virtual) {
			this.handler = handler;
			this.msg = msg;
			this.nodeid = nodeid;
			this.nickname = nickname;
			this.virtual = virtual;
		}

		@Override
		public void run() {
			boolean ret = IotaClient.getServiceInterface().registerSANode(nodeid, nickname, virtual);
			Message m = handler.obtainMessage(msg);
			Result r = new Result(ret, Boolean.valueOf(virtual));
			m.obj = r;
			handler.sendMessage(m);
		}
	}

	private static class UnregisterSANodeRunner implements IClientRunner {
		Handler handler;
		int msg;
		String nodeid;

		UnregisterSANodeRunner(Handler handler, int msg, String nodeid) {
			this.handler = handler;
			this.msg = msg;
			this.nodeid = nodeid;
		}

		@Override
		public void run() {
			boolean ret = IotaClient.getServiceInterface().unregisterSANode(nodeid);
			Message m = handler.obtainMessage(msg);
			Result r = new Result(ret, null);
			m.obj = r;
			handler.sendMessage(m);
		}
	}

	private static class GetClientHistoryRunner implements IClientRunner {
		Handler handler;
		int msg;

		GetClientHistoryRunner (Handler handler, int msg) {
			this.handler = handler;
			this.msg = msg;
		}

		@Override
		public void run() {
			String log = IotaClient.getServiceInterface().getClientHistory();

			if (log != null && log.length() > 0) {
				handler.removeMessages(msg);
				Message m = handler.obtainMessage(msg);
				m.obj = log;
				handler.sendMessage(m);
			}
		}
	}

	private static interface IClientRunner {
		public void run();
	}

	private static class Runner extends AsyncTask<IClientRunner, Void, Void> {
		@Override
		protected Void doInBackground(IClientRunner... params) {
			params[0].run();
			return null;
		}
	}
}
