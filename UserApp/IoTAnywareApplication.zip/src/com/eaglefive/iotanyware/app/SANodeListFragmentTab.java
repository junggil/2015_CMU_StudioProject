package com.eaglefive.iotanyware.app;

import com.eaglefive.iotanyware.node.Event;
import com.eaglefive.iotanyware.node.SANode;
import com.eaglefive.iotanyware.node.SANodeList;
import com.eaglefive.iotanyware.node.SANodeList.ItemPresentation;
import com.eaglefive.iotanyware.service.client.IotaClient;

import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class SANodeListFragmentTab extends Fragment {
	private static final String TAG = "SANodeListFragmentTab";
	private Handler mHandler;
	private SANodeListAdapter mListAdapter;
	private SANodeList mSANodeList;

	SANodeListFragmentTab(Handler h) {
		mHandler = h;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_sanodelist, container, false);
		final ListView list = (ListView) rootView.findViewById(R.id.lvSANode);
		mSANodeList = new SANodeList();
		mListAdapter = new SANodeListAdapter(inflater);
		list.setAdapter(mListAdapter);

		list.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				ItemPresentation item = mSANodeList.getPresentableItem(position);
				String actuatorName = item.getID();
				String control = item.getNextControlValue();
				String nodeID = mSANodeList.findOwner(item);
				String userID = IotaClient.getClientID();
				String payload = Event.getPayloadControl(userID, actuatorName, control);
				if (control == null || nodeID == null || userID == null || payload == null) {
					return;
				}
				IotaClient.getEventServiceInterface().sendEvent(Event.CATEGORY_SANODE, nodeID, Event.METHOD_CONTROL, payload);
			}
	    });

		refreshNodeList();
		return rootView;
	}

	public void refreshNodeList() {
		IotaClientRunner.getSANodeList(mHandler, Main.MSG_SANODELIST);
	}

	public void updateNodeList(String payload) {
		mSANodeList.updateNodeList(payload);
		mListAdapter.notifyDataSetChanged();
	}

	public void setEventBusLlistener() {
		int i;
		for (i = 0; i < mSANodeList.getNumberOfSANodes(); i++) {
			IotaClient.getEventServiceInterface().setListeningEvent(Event.CATEGORY_SANODE, mSANodeList.getSANodeID(i));
		}

		for (i = 0; i < mSANodeList.getNumberOfSANodes(); i++) {
			IotaClient.getEventServiceInterface().sendEvent(Event.CATEGORY_SANODE, mSANodeList.getSANodeID(i), Event.METHOD_QUERY, "");
		}
	}

	public void message(String id, String method, String payload) {
		if (Event.METHOD_NOTIFY.equals(method)) {
			// TODO: update notification
		} else if (Event.METHOD_STATUS.equals(method)) {
			boolean ret = mSANodeList.updateSAValue(id, payload);
			Log.i(TAG, "SA value updated: " + ret);
			mListAdapter.notifyDataSetChanged();  // TODO: partial update
		}
		// TODO: process other methods
	}

	public int getNumberOfSANodes() {
		return mSANodeList.getNumberOfSANodes();
	}

	public String getSANodeDescription(int idx) {
		return mSANodeList.getSANodeDescription(idx);
	}

	public String getSANodeID(int idx) {
		return mSANodeList.getSANodeID(idx);
	}

	private class SANodeListAdapter extends BaseAdapter {
		private static final int TYPE_TITLE = 0;
		private static final int TYPE_ITEM = 1;
		private LayoutInflater mInflater;

		public SANodeListAdapter(LayoutInflater inflater) {
			mInflater = inflater;
		}

		@Override
		public int getCount() {
			return mSANodeList.getNumberOfPresentableItems();
		}

		@Override
		public Object getItem(int position) {
			return mSANodeList.getPresentableItemDesc(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			int type = mSANodeList.getItemType(position);

			switch (type) {
				case ItemPresentation.TYPE_ACTUATOR:
					convertView = mInflater.inflate(R.layout.sanode_listitem_item, null);
					((TextView)convertView.findViewById(R.id.txDescription)).setText(mSANodeList.getPresentableItemDesc(position));
					((ImageView)convertView.findViewById(R.id.imgIcon)).setImageResource(R.drawable.up);
					break;
				case ItemPresentation.TYPE_SANODE:
					convertView = mInflater.inflate(R.layout.sanode_listitem_title, null);
					((TextView)convertView.findViewById(R.id.txTitle)).setText(mSANodeList.getPresentableItemDesc(position));
					break;
				case ItemPresentation.TYPE_SENSOR:
				default:  // invalid type but...
					convertView = mInflater.inflate(R.layout.sanode_listitem_item, null);
					((TextView)convertView.findViewById(R.id.txDescription)).setText(mSANodeList.getPresentableItemDesc(position));
					((ImageView)convertView.findViewById(R.id.imgIcon)).setImageResource(R.drawable.download);
					break;
			}
			return convertView;
        }		
	}
}
