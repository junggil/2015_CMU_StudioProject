package com.eaglefive.iotanyware.app;

import com.eaglefive.iotanyware.app.R;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends Activity {

	private static final String PREFERENCE_CATALOG_LOGIN = "app_prefs";
	private static final String PREFERENCE_EMAIL = "email";

	private Handler mHandler;
	private Button mBtnSignIn;
	private EditText mEtEmail;
	private EditText mEtPassword;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);

		mBtnSignIn = (Button)findViewById(R.id.btnSingIn);
		mEtEmail = (EditText)findViewById(R.id.etEmail);
		mEtPassword = (EditText)findViewById(R.id.etPassword);

		String email = getEmail();
		if (email != null && email.length() > 0) {
			mEtEmail.setText(email);
		}

		assignEventListener();

		mHandler = new Handler(getMainLooper()) {
			@Override
	        public void handleMessage(Message msg) {
				switch(msg.what) {
				case IotaClientRunner.MSG_SUCCESS:
					saveEmail();
					Toast.makeText(Login.this, "login success!", Toast.LENGTH_SHORT).show();
					Intent i = new Intent(Login.this, Main.class);
					i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(i);
					break;
				case IotaClientRunner.MSG_FAILURE:
					Toast.makeText(Login.this, "Failed to login!", Toast.LENGTH_SHORT).show();
					mBtnSignIn.setEnabled(true);
					break;
				}
			}
		};
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.

		return super.onOptionsItemSelected(item);
	}

	private void saveEmail() {
	    SharedPreferences pref = getSharedPreferences(PREFERENCE_CATALOG_LOGIN, 0);
	    SharedPreferences.Editor edit = pref.edit();
	    edit.putString(PREFERENCE_EMAIL, mEtEmail.getText().toString());
	    edit.commit();
	}

	private String getEmail() {
		SharedPreferences pref = getSharedPreferences(PREFERENCE_CATALOG_LOGIN,0);
		return pref.getString(PREFERENCE_EMAIL, "");
	}
	private void assignEventListener() {
		final Button btnRegister = (Button) findViewById(R.id.btnRegister);
		btnRegister.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent i = new Intent(Login.this, RegisterAccount.class);
				startActivity(i);
			}
		});

		mBtnSignIn = (Button) findViewById(R.id.btnSingIn);
		mBtnSignIn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				String email = mEtEmail.getText().toString();
				String password = mEtPassword.getText().toString();

				if ((email == null || email.length() <= 0) ||
					(password == null || password.length() <= 0)) {
					Toast.makeText(Login.this, "Incorrect Input!", Toast.LENGTH_SHORT).show();
					return;
				}
				mBtnSignIn.setEnabled(false);
				IotaClientRunner.login(mHandler, email, password);
			}
		});
	}
}
