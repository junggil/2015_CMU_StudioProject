package com.eaglefive.iotanyware.app;

import com.eaglefive.iotanyware.app.IotaClientRunner.Result;
import com.eaglefive.iotanyware.node.Event;
import com.eaglefive.iotanyware.service.client.IIotaEventCallback;
import com.eaglefive.iotanyware.service.client.IotaClient;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class Main extends Activity implements IIotaEventCallback {
	private static final String TAG = "Main";

	static final int MSG_SANODELIST = 0;
	static final int MSG_SANODEREGISTER = 1;
	static final int MSG_SANODEUNREGISTER = 2;
	static final int MSG_EVENTCLIENT_CONNECT = 3;

	private ActionBar.Tab mSANodeListTab;
	private ActionBar.Tab mNotificationListTab;
	private ActionBar.Tab mHistoryTab;
	private SANodeListFragmentTab mSANodeListFT;
	private Fragment mNotificationListFT;
	private Fragment mHistoryFT;
	public Handler mHandler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		ActionBar actionBar = getActionBar();
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		setHandler();

		mSANodeListFT = new SANodeListFragmentTab(mHandler);
		mNotificationListFT = new NotificationListFragmentTab();
		mHistoryFT = new HistoryFragmentTab();

		mSANodeListTab = actionBar.newTab().setText("Home Control");
		mNotificationListTab = actionBar.newTab().setText("Notification");
		mHistoryTab = actionBar.newTab().setText("Log");

		mSANodeListTab.setTabListener(new TabListener(mSANodeListFT));
		mNotificationListTab.setTabListener(new TabListener(mNotificationListFT));
		mHistoryTab.setTabListener(new TabListener(mHistoryFT));

		actionBar.addTab(mSANodeListTab);
		actionBar.addTab(mNotificationListTab);
		actionBar.addTab(mHistoryTab);

		IotaClient.initializeEventService(Main.this, Main.this);
		mHandler.sendEmptyMessage(MSG_EVENTCLIENT_CONNECT);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_registersanode) {
			final Dialog dialog = new Dialog(this);
			dialog.setContentView(R.layout.dialog_registersanode);
			dialog.setTitle("SA Node Register");

			final EditText txSN = (EditText) dialog.findViewById(R.id.etSerialnumber);
			final EditText txNickname = (EditText) dialog.findViewById(R.id.etNickname);
			final CheckBox cbVirtual = (CheckBox) dialog.findViewById(R.id.cbVirtual);
			Button b = (Button) dialog.findViewById(R.id.btnRegister);
			b.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					String serialnumber = txSN.getText().toString();
					String nickname = txNickname.getText().toString();
					boolean virtual = cbVirtual.isChecked();
					IotaClientRunner.registerSANode(mHandler, MSG_SANODEREGISTER, serialnumber, nickname, virtual);
					dialog.dismiss();
				}
			});
			dialog.show();
			return true;
		} else if (id == R.id.action_unregistersanode) {
			if (mSANodeListFT.getNumberOfSANodes() <= 0) {
				Toast.makeText(this, "No registered SA nodes!", Toast.LENGTH_SHORT).show();
				return true;
			}
			final Dialog dialog = new Dialog(this);
			dialog.setContentView(R.layout.dialog_unregistersanode);
			dialog.setTitle("SA Node Unregister");

			ListView lv = (ListView)dialog.findViewById(R.id.lvSANodeList);
			ArrayAdapter<String> aa = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
			int num = mSANodeListFT.getNumberOfSANodes();
			for (int i = 0; i < num; i++) {
				aa.add(mSANodeListFT.getSANodeDescription(i));
			}
			lv.setAdapter(aa);
			
			lv.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					IotaClientRunner.unregisterSANode(mHandler, MSG_SANODEUNREGISTER, mSANodeListFT.getSANodeID(position));
					dialog.dismiss();
				}
			});
			dialog.show();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public class TabListener implements ActionBar.TabListener {
		private Fragment mFragment;

		public TabListener(Fragment fragment) {
			mFragment = fragment;
		}

		@Override
		public void onTabSelected(Tab tab, FragmentTransaction ft) {
			ft.replace(R.id.activity_main, mFragment);
		}

		@Override
		public void onTabUnselected(Tab tab, FragmentTransaction ft) {
			ft.remove(mFragment);
		}

		@Override
		public void onTabReselected(Tab tab, FragmentTransaction ft) {
		}
	}

	private void setHandler() {
		mHandler = new Handler(getMainLooper()) {
			@Override
	        public void handleMessage(Message msg) {
				switch(msg.what) {
				case MSG_SANODELIST:
					mSANodeListFT.updateNodeList((String)msg.obj);
					break;
				case MSG_SANODEREGISTER:
					if (msg.obj != null) {
						Result r = (Result)msg.obj;
						if (r.result) {
							if (((Boolean)r.obj).booleanValue()) {
								Toast.makeText(Main.this, "Virtual node registered!", Toast.LENGTH_SHORT).show();
								mSANodeListFT.refreshNodeList();
							} else {
								Toast.makeText(Main.this, "To complete the registration, manipulate the SA node to connect to the system!", Toast.LENGTH_LONG).show();
							}
						} else {
							Toast.makeText(Main.this, "SA node registration failed!", Toast.LENGTH_SHORT).show();
						}
					}
					break;
				case MSG_SANODEUNREGISTER:
					if (msg.obj != null) {
						Result r = (Result)msg.obj;
						if (r.result) {
							Toast.makeText(Main.this, "SA node unregistered!", Toast.LENGTH_SHORT).show();
							mSANodeListFT.refreshNodeList();
						} else {
							Toast.makeText(Main.this, "SA node unregistration failed!", Toast.LENGTH_SHORT).show();
						}
					}
					break;
				case MSG_EVENTCLIENT_CONNECT:
					boolean ret = IotaClient.getEventServiceInterface().connect();
					if (ret == false) {
						removeMessages(MSG_EVENTCLIENT_CONNECT);
						Message m = obtainMessage(MSG_EVENTCLIENT_CONNECT);
						sendMessageDelayed(m, 10000);
						Toast.makeText(Main.this, "Failed to connect to event bus!", Toast.LENGTH_LONG).show();
						break;
					}
					break;
				}
			}
		};
	}

	@Override
	public void reconnection(boolean result) {
		Toast.makeText(Main.this, "Reconnected!", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void message(String category, String id, String method,
			String payload) {
		// TODO: handle heartbeat
		Log.i(TAG, category + ", " + id + ", " + method + ", " + payload);
		if (Event.CATEGORY_USER.equals(category) && Event.METHOD_REGISTER.equals(method)) {
			mSANodeListFT.refreshNodeList();
		} else if (Event.CATEGORY_SANODE.equals(category)) {
			mSANodeListFT.message(id, method, payload);
		}
	}

	@Override
	public void onConnection(boolean result) {
		Log.i(TAG, "MQTT connection: " + result);
		if (result == false) {
			Toast.makeText(Main.this, "Failed to connect to event bus!", Toast.LENGTH_LONG).show();
		} else {
			IotaClient.getEventServiceInterface().setListeningEvent(Event.CATEGORY_USER);
			mSANodeListFT.setEventBusLlistener();
		}
	}
}
