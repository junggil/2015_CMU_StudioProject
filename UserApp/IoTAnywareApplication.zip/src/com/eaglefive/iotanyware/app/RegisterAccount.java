package com.eaglefive.iotanyware.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterAccount extends Activity {

	private Handler mHandler;
	private Button mBtnSignUp;
	private EditText mEtEmail;
	private EditText mEtNickname;
	private EditText mEtPassword;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);

		mBtnSignUp = (Button)findViewById(R.id.btnSingUp);
		mEtEmail = (EditText)findViewById(R.id.etEmail);
		mEtNickname = (EditText)findViewById(R.id.etNickname);
		mEtPassword = (EditText)findViewById(R.id.etPassword);

		assignEventListener();

		mHandler = new Handler(getMainLooper()) {
			@Override
	        public void handleMessage(Message msg) {
				switch(msg.what) {
				case IotaClientRunner.MSG_SUCCESS:
					Toast.makeText(RegisterAccount.this, "register success!", Toast.LENGTH_SHORT).show();
					finish();
					break;
				case IotaClientRunner.MSG_FAILURE:
					Toast.makeText(RegisterAccount.this, "Failed to register!", Toast.LENGTH_SHORT).show();
					mBtnSignUp.setEnabled(true);
					break;
				}
			}
		};
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		return super.onOptionsItemSelected(item);
	}

	private void assignEventListener() {
		mBtnSignUp.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				String email = mEtEmail.getText().toString();
				String nickname = mEtNickname.getText().toString();
				String password = mEtPassword.getText().toString();

				if ((email == null || email.length() <= 0) ||
					(nickname == null || nickname.length() <= 0) ||
					(password == null || password.length() <= 0)) {
					Toast.makeText(RegisterAccount.this, "Incorrect Input!", Toast.LENGTH_SHORT).show();
					return;
				}
				mBtnSignUp.setEnabled(false);
				IotaClientRunner.registerAccount(mHandler, email, nickname, password);
			}
		});
	}
}
