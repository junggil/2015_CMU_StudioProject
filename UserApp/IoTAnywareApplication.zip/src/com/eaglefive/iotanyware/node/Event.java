package com.eaglefive.iotanyware.node;

import java.io.IOException;
import java.io.StringWriter;

import org.json.simple.JSONObject;

public class Event {
	public static final String CATEGORY_USER =		"user";
	public static final String CATEGORY_SANODE =	"sanode";

	public static final String METHOD_CONTROL =		"control";
	public static final String METHOD_QUERY =		"query";

	public static final String METHOD_CONFIG =		"config";
	public static final String METHOD_HEARTBEAT =	"heartbeat";
	public static final String METHOD_NOTIFY =		"notify";
	public static final String METHOD_REGISTER =	"register";
	public static final String METHOD_STATUS =		"status";

	public static final String FIELD_PUBLISHER =	"publisher";
	public static final String FIELD_NAME =			"name";
	public static final String FIELD_VALUE =		"value";

	public static String getPayloadControl(String userID, String actuatorName, String value) {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put(FIELD_PUBLISHER, userID);
		jsonObj.put(FIELD_NAME, actuatorName);
		jsonObj.put(FIELD_VALUE, value);

		StringWriter toStr = new StringWriter();
		try {
			jsonObj.writeJSONString(toStr);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String payload = jsonObj.toString();
		return payload;
	}

	public static String getPayloadQuery(String userId) {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put(FIELD_PUBLISHER, userId);
		
		StringWriter toStr = new StringWriter();
		try {
			jsonObj.writeJSONString(toStr);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String payload = jsonObj.toString();
		return payload;
	}
}
