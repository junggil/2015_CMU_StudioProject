package com.eaglefive.iotanyware.node;

import java.util.ArrayList;
import java.util.HashMap;

import com.eaglefive.iotanyware.node.SANodeList.ItemPresentation;

public class SANode implements ItemPresentation {
	private String mNodeID;
	private String mNickname;
	private boolean mOwner;
	private ArrayList<SensorActuator> mSAList = new ArrayList<SensorActuator>();

	public SANode(String nodeID, String nickname, boolean owner) {
		mNodeID = nodeID;
		mNickname = nickname;
		mOwner = owner;
	}

	public SANode addSA(String saName, String profile) {
		mSAList.add(SensorActuator.makeSA(saName, profile));
		return this;
	}

	public boolean contains(SensorActuator sa) {
		return mSAList.contains(sa);
	}

	public String getNodeID() {
		return mNodeID;
	}

	public boolean updateValue(String saName, String value) {
		for(SensorActuator sa: mSAList) {
			if (saName.equals(sa.getName())) {
				sa.updateValue(value);
				return true;
			}
		}
		return false;
	}

	public int getNumberOfPresentables() {
		return mSAList.size() + 1;
	}

	public ItemPresentation getItemPresentation(int idx) {
		// presentable items = sensor + actuator + sa node
		if (idx < 0 || idx >= mSAList.size() + 1) {
			return null;
		} else if (idx == 0) {
			return this;
		}
		return mSAList.get(idx - 1);
	}

	@Override
	public String getDescription() {
		StringBuilder sb = new StringBuilder(mNickname);
		if (mOwner) {
			sb.append(" (Owned)");
		}
		return sb.toString();
	}

	@Override
	public int getType() {
		return TYPE_SANODE;
	}

	@Override
	public String getID() {
		return mNodeID;
	}

	@Override
	public String getNextControlValue() {
		return null;
	}

	public static class SensorActuator implements ItemPresentation {
		private static HashMap<String, Profile> sProfiles = new HashMap<String, Profile>();
		static { // TODO: get profiles from the server
			sProfiles.put("com.genetic.alarm", 
					new Profile (true, 2, 
							new String[] {"on", "off"},
							new String[] {"On", "Off"}));
			sProfiles.put("com.genetic.door", 
					new Profile (true, 2,
							new String[] {"open", "close"},
							new String[] {"Open", "Close"}));
			sProfiles.put("com.genetic.light", 
					new Profile (true, 0, null, null));
			sProfiles.put("com.genetic.humidity", 
					new Profile (false, 0, null, null));
			sProfiles.put("com.genetic.proximity", 
					new Profile (false, 0, null, null));
			sProfiles.put("com.genetic.thermostat", 
					new Profile (false, 0, null, null));
		}

		public static SensorActuator makeSA(String saName, String profile) {
			Profile p = sProfiles.get(profile);
			if (p == null) {
				p = new Profile (false, 0, null, null);  // make null profile until updated
			}
			return new SensorActuator (saName, p);
		}

		private String mName;
		private Profile mProfile;
		private String mValue;

		public SensorActuator(String saName, Profile p) {
			mName = saName;
			mProfile = p;
		}

		public String getName() {
			return mName;
		}

		public void updateValue(String value) {
			mValue = value;
		}

		@Override
		public String getDescription() {
			String val;
			if (mValue == null) {
				val = "Unknown";
			} else {
				val = mValue;
			}
			return String.format("%s: %s", mName, val);
		}

		@Override
		public int getType() {
			if (mProfile.isControlable) {
				return TYPE_ACTUATOR;
			}
			return TYPE_SENSOR;
		}

		@Override
		public String getID() {
			return mName;
		}

		@Override
		public String getNextControlValue() {
			if (mValue == null) {
				return null;
			}

			if (mProfile.isControlable) {
				for (int i = 0; i < mProfile.numControls; i++) {
					if (mValue.equals(mProfile.controls[i])) {
						int nextControlIdx = i + 1;
						if (nextControlIdx >= mProfile.numControls) {
							nextControlIdx = 0;
						}
						return mProfile.controls[nextControlIdx];
					}
				}
			}
			return null;
		}
	}

	public static class Profile {
		final boolean isControlable;
		final int numControls;
		final String[] controls;
		final String[] controlDescs;
		// TODO: value range checking

		Profile(boolean isControlable, int numControls, String[] controls, String[] contorlDescs) {
			this.isControlable = isControlable;
			this.numControls = numControls;
			this.controls = controls;
			this.controlDescs = contorlDescs;
		}
	}
}
