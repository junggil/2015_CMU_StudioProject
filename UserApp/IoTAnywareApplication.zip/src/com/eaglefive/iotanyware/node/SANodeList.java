package com.eaglefive.iotanyware.node;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.eaglefive.iotanyware.node.SANode.SensorActuator;

import android.util.Log;

public class SANodeList {
	private static final String TAG = "SANodeList";
	private static final String SANODELIST_FIELD_RESULT =		"result";
	private static final String SANODELIST_FIELD_NODEID =		"node";
	private static final String SANODELIST_FIELD_NICKNAME =		"nickName";
	private static final String SANODELIST_FIELD_OWNER =		"owner";
	private static final String SANODELIST_FIELD_PROFILES =		"profiles";
	private static final String SANODELIST_FIELD_SANAME =		"name";
	private static final String SANODELIST_FIELD_SAPROFILE =	"profile";

	private ArrayList<SANode> mSANodeList;
	private ArrayList<ItemPresentation> mPresentation;

	public void updateNodeList(String payload) {
		Log.i(TAG, payload);

		mSANodeList = new ArrayList<SANode>();
		mPresentation = new ArrayList<ItemPresentation>();

		try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser.parse(payload);
			JSONArray  resultInfoArray = (JSONArray) jsonObject.get(SANODELIST_FIELD_RESULT);

			for(int i = 0; i < resultInfoArray.size(); i++) {
				JSONObject nodeObj  = (JSONObject) resultInfoArray.get(i);
				String nodeID = (String)nodeObj.get(SANODELIST_FIELD_NODEID);
				String nickname = (String)nodeObj.get(SANODELIST_FIELD_NICKNAME);
				Boolean owner = (Boolean)nodeObj.get(SANODELIST_FIELD_OWNER);
				Log.i(TAG, nodeID + ", " + nickname + ", " + owner);

				JSONArray saProfiles = (JSONArray) jsonObject.get(SANODELIST_FIELD_PROFILES);

				SANode s = new SANode(nodeID, nickname, owner.booleanValue());

				// TODO: query system for profiles

				if (saProfiles == null) {
					s.addSA("alarm", "com.genetic.alarm");
					s.addSA("door", "com.genetic.door");
					s.addSA("humidity", "com.genetic.humidity");
					s.addSA("light", "com.genetic.light");
					s.addSA("proximity", "com.genetic.proximity");
					s.addSA("thermostat", "com.genetic.thermostat");
				} else {
					for (int j = 0; j < saProfiles.size(); j++) {
						JSONObject profileObject;
						String name, profile;
						profileObject = (JSONObject)saProfiles.get(i);
						name = (String)profileObject.get(SANODELIST_FIELD_SANAME);
						profile = (String)profileObject.get(SANODELIST_FIELD_SAPROFILE);
						s.addSA(name, profile);
					}
				}

				int numPresentables = s.getNumberOfPresentables();
				for (int k = 0; k < numPresentables; k++) {
					mPresentation.add(s.getItemPresentation(k));
				}

				mSANodeList.add(s);
			}
		} catch (ParseException e) {
			Log.i(TAG, e.toString());
		}
	}

	public String findOwner(ItemPresentation item) {
		if (mSANodeList == null) {
			return null;
		}

		for (SANode s: mSANodeList) {
			if (s == item) {
				return s.getNodeID();
			}
			if(s.contains((SensorActuator)item)) {
				return s.getNodeID();
			}
		}

		return null;
	}

	public int getNumberOfSANodes() {
		if (mSANodeList == null) {
			return 0;
		}

		return mSANodeList.size();
	}

	public String getSANodeDescription(int idx) {
		if (mSANodeList == null) {
			return null;
		}
		return mSANodeList.get(idx).getDescription();
	}

	public String getSANodeID(int idx) {
		if (mSANodeList == null) {
			return null;
		}
		return mSANodeList.get(idx).getNodeID();
	}

	public boolean updateSAValue(String nodeID, String payload) {
		if (mSANodeList == null || nodeID == null || payload == null) {
			return false;
		}

		boolean ret = false;

		for (SANode s: mSANodeList) {
			if (nodeID.equals(s.getNodeID())) {
				JSONParser parser = new JSONParser();
				ContainerFactory containerFactory = new ContainerFactory() {
					public Map createObjectContainer() {
						return new LinkedHashMap();
					}
					public List creatArrayContainer() {
						return new LinkedList();
					}
				};

				try {
					Map json = (Map)parser.parse(payload, containerFactory);
					Iterator iter = json.entrySet().iterator();
					while(iter.hasNext()) {
						Map.Entry entry = (Map.Entry)iter.next();
						String saName = entry.getKey().toString();
						String value = entry.getValue().toString();

						Log.i(TAG, saName + " =>" + value);

						if (s.updateValue(saName, value)) {
							ret = true; // one success count
						}
					}		
				} 
				catch (ParseException e) {
					Log.i(TAG, e.toString());
				}
				break;
			}
		}

		return false;
	}

	public int getNumberOfPresentableItems() {
		if (mPresentation == null) {
			return 0;
		}
		return mPresentation.size();
	}

	public ItemPresentation getPresentableItem(int idx) {
		if (mPresentation == null) {
			return null;
		}

		return mPresentation.get(idx);
	}

	public String getPresentableItemDesc(int idx) {
		if (mPresentation == null) {
			return null;
		}
		return mPresentation.get(idx).getDescription();
	}

	public int getItemType(int idx) {
		if (mPresentation == null) {
			return -1;
		}
		return mPresentation.get(idx).getType();
	}

	public static interface ItemPresentation {
		public static final int TYPE_SANODE = 0;
		public static final int TYPE_SENSOR = 1;
		public static final int TYPE_ACTUATOR = 2;

		String getID();
		String getDescription();
		int getType();
		String getNextControlValue();  // TODO: detach this prom ItemPresentation
	}
}
