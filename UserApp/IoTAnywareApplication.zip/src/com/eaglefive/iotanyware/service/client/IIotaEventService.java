package com.eaglefive.iotanyware.service.client;

public interface IIotaEventService {
	public boolean connect();
	public boolean setListeningEvent(String category);
	public boolean setListeningEvent(String category, String id);
	public boolean sendEvent(String category, String id, String method, String payload);
}
