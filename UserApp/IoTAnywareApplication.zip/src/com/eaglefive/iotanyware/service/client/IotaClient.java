package com.eaglefive.iotanyware.service.client;

import android.content.Context;

public class IotaClient { // TODO: asynchronous interface
	private static final String DEFAULT_SERVER_URL = "54.166.26.101";

	private static HttpClient mHttpClient;
	private static MqttEventClient mMqttClient;

	public static IIotaService getServiceInterface() {
		IIotaService service = null;
		if (mHttpClient == null) {
			mHttpClient = new HttpClient("http://" + getServerURL() + ":8000");
		}

		service = (IIotaService) mHttpClient;

		return service; 
	}

	public static boolean initializeEventService(Context context, IIotaEventCallback callback) {
		if (mMqttClient == null) {
			if (mHttpClient != null) {
				String sessionID = mHttpClient.getSessionID();
				String userID = mHttpClient.getUserID();
				if (sessionID != null && userID != null) {
					mMqttClient = new MqttEventClient(context, getServerURL(), userID, sessionID, callback);
					return true;
				}
			} else {
				return false;
			}
		}
		return false;
	}

	public static IIotaEventService getEventServiceInterface() {
		IIotaEventService service = null;

		if (mMqttClient == null) {
			return null;
		}

		service = (IIotaEventService)mMqttClient;

		return service;
	}

	public static String getClientID() {
		if (mHttpClient == null) {
			return null;
		}

		return mHttpClient.getUserID();
	}

	private static String getServerURL() {
		return DEFAULT_SERVER_URL;
	}
}
