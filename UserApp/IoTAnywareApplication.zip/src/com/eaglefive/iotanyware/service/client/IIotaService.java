package com.eaglefive.iotanyware.service.client;

public interface IIotaService {
	// account services
	public boolean register(String email, String password, String nickname);
	public boolean unregister(String email, String password);
	public boolean login(String email, String password); 

	// login() prior to call below functions
	// SA node services
	public String getSANodeList();
	public String getSAProfile();
	public String getSANodeName(String node);
	public boolean registerSANode(String nodeid, String nickName, boolean virtual);
	public boolean unregisterSANode(String nodeid);

	// analytic services
	public String getClientHistory();
}
