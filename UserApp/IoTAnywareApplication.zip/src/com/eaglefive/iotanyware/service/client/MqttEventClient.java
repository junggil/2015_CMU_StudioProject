package com.eaglefive.iotanyware.service.client;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import android.content.Context;
import android.util.Log;

public class MqttEventClient implements IIotaEventService, MqttCallback {
	private static final String TAG = "MqttEventClient";

	private static String mServerURL;
	private String mSessionID;
	private String mUserID;
	private IIotaEventCallback mEventCallback;
	private MqttAndroidClient mClient;
	private Context mContext;
	private String mClientHandle;

	MqttEventClient(Context context, String url, String userID, String sessionID, IIotaEventCallback eventCallBack) {
		mContext = context;
		mServerURL = url;
		mUserID = userID;
		mSessionID = sessionID;
		mEventCallback = eventCallBack;
	}

	public boolean connect() {
		MqttConnectOptions conOpt = new MqttConnectOptions();
		String port = "1883";
		String uri = "tcp://" + mServerURL + ":" + port;
	    boolean cleanSession = true;

	    mClientHandle = uri + mSessionID;

	    mClient = Connections.getInstance(mContext)
	            .createClient(mContext, uri, mSessionID);
	    Connection conn = new Connection(mClientHandle, mSessionID, mServerURL, 1883,
	            mContext, mClient, false);

	    conOpt.setCleanSession(cleanSession);
	    // conOpt.setConnectionTimeout(timeout);
	    conOpt.setKeepAliveInterval(100);

	    conn.addConnectionOptions(conOpt);
	    Connections.getInstance(mContext).addConnection(conn);

	    try {
	        IMqttToken t = mClient.connect(conOpt, null, new IMqttActionListener() {
				@Override
				public void onFailure(IMqttToken arg0, Throwable arg1) {
					Log.e(TAG, arg1.toString());
					mEventCallback.onConnection(false);
				}

				@Override
				public void onSuccess(IMqttToken arg0) {
					mEventCallback.onConnection(true);
				}
			});
	        //t.waitForCompletion(90);
	        mClient.setCallback(this);
	        return true;
	    } catch (MqttException e) {
	        e.getCause();
	    } catch (NullPointerException e) {
	        e.getCause();
	    } catch (Exception e) {
	        e.getCause();
	    }
	    return false;
	}

	@Override
	public boolean setListeningEvent(String category) {
		if (category == null) {
			return false;
		}

		return setListeningEvent(category, mUserID);
	}

	@Override
	public boolean setListeningEvent(String category, String id) {
		if (category == null || id == null) {
			return false;
		}

		try {
			String topic;
			topic = String.format("/%s/%s/#", category, id);
			Log.i(TAG, "addSubscribeTopic = " + topic);
			mClient.subscribe(topic, 0, mContext, new IMqttActionListener() {
				@Override
				public void onFailure(IMqttToken arg0, Throwable arg1) {
				}

				@Override
				public void onSuccess(IMqttToken arg0) {
				}				
			});
			return true;
		} catch (MqttException e) {
			Log.i(TAG, e.toString());
			return false;
		}
	}

	@Override
	public boolean sendEvent(String category, String id, String method, String payload) {
		if (category == null || id == null || method == null) {
			return false;
		}

		String topic;
		topic = String.format("/%s/%s/%s", category, id, method);
		MqttMessage message = new MqttMessage(payload.getBytes());
		message.setQos(0);

    	try {
	        mClient.publish(topic, message);
	        Log.i(TAG, "Message published");
	        return true;
    	} catch(MqttException e) {
    		Log.i(TAG, e.toString());
            return false;
        }
	}

	@Override
	public void connectionLost(Throwable arg0) {
		boolean res;

		Log.i(TAG, "connection lost!");
		try {
			mClient.connect();
			res = true;
		} catch (MqttException e) {
			Log.i(TAG, e.toString());
			res = false;
		}
		mEventCallback.reconnection(res);
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {
		// TODO Auto-generated method stub
	}

	@Override
	public void messageArrived(String arg0, MqttMessage arg1) throws Exception {
		Log.i(TAG, "Topic: " + arg0);
		Log.i(TAG, "Contents: " + arg1.toString());

		String[] topicStack = arg0.split("/");

		if (topicStack == null)
			return;

		for (int i = 0; i < topicStack.length; i++) {
			Log.i(TAG, "Topic " + i + ": " + topicStack[i]);
		}

		if (topicStack.length > 3) {
			mEventCallback.message(topicStack[1], topicStack[2], topicStack[3], arg1.toString());
		}
	}
}
