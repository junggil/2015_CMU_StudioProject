package com.eaglefive.iotanyware.service.client;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.eaglefive.iotanyware.service.client.restclient.HTTPRequest;
import com.eaglefive.iotanyware.service.client.restclient.HTTPResponse;

public class HttpClient implements IIotaService {
	private static final String TAG = "HttpClient";
	private static String mServerURL;
	private static final String HEADER_CONTENT_KEY  = "Content-Type";
	private static final String HEADER_CONTENT_VAL  = "application/json";
	private static final String HEADER_CLIENTID_KEY  = "x-client-id";
	private static final String HEADER_CLIENTID_VAL  = "75f9e675-9db4-4d02-b523-37521ef656ea";	
	private static final String BODY_EMAIL_KEY = "email";
	private static final String BODY_PASSWORD_KEY = "password";
	private static final String BODY_SESSIONID_KEY = "session";
	private static final String BODY_NODEID_KEY = "nodeId";
	private static final String BODY_NICKNAME_KEY = "nickName";
	private static final String BODY_VIRTUAL_KEY = "virtual";

	private static final int HTTP_RESP_SUCCESS = 200;

	private String mSessionID;
	private String mUserID;

	public HttpClient(String url) {
		mServerURL = url;
	}

	@Override
	public boolean register(String email, String nickname, String password) {
		HTTPRequest httprequest = new HTTPRequest();
		HTTPResponse httpresponse;
		String uri = mServerURL + "/account/registerNewUser";

		HashMap<String, String> headers = new HashMap<String, String>(); 
		HashMap<String, String> body = new HashMap<String, String>();

		Log.i(TAG, uri);
		try {
			// 1.Handle HTTP request
			headers.put(HEADER_CONTENT_KEY, HEADER_CONTENT_VAL);
			headers.put(HEADER_CLIENTID_KEY, HEADER_CLIENTID_VAL);
			
			body.put(BODY_PASSWORD_KEY, password);
			body.put(BODY_EMAIL_KEY, email);
			body.put(BODY_NICKNAME_KEY, nickname);			

			httpresponse = httprequest.post(uri, httprequest.propertyString(body), headers);

			// 2.Handle HTTP response
			String resString = URLDecoder.decode(httpresponse.getString(), "UTF-8");
			Log.i(TAG, resString);

			// 3. JSON parse the response
    		JSONObject jresString = new JSONObject(resString);
    		Object jstatusCode = jresString.get("statusCode");
    		
    		if((int)jstatusCode == HTTP_RESP_SUCCESS)
    			return true;
    		else 
    			return false;
		} catch (IOException | JSONException  e) {
			Log.i(TAG, e.toString());
			return false;
		}	
	}

	@Override
	public boolean unregister(String email, String password) {
		return false;
	}

	@Override
	public boolean login(String email, String password) {
		HTTPRequest httprequest = new HTTPRequest();
		HTTPResponse httpresponse;
		String uri = mServerURL + "/session/createUser";

		HashMap<String, String> headers = new HashMap<String, String>(); 
		HashMap<String, String> body = new HashMap<String, String>();

		Log.i(TAG, uri);
		try {
			// 1.Handle HTTP request
			headers.put(HEADER_CONTENT_KEY, HEADER_CONTENT_VAL);
			headers.put(HEADER_CLIENTID_KEY, HEADER_CLIENTID_VAL);

			body.put(BODY_PASSWORD_KEY, password);
			body.put(BODY_EMAIL_KEY, email);

			httpresponse = httprequest.post(uri, httprequest.propertyString(body), headers);

			// 2.Handle HTTP response
			String resString = URLDecoder.decode(httpresponse.getString(), "UTF-8");
			Log.i(TAG, resString);

			// 3. JSON parse the response
			JSONObject jresString = new JSONObject(resString);
			Object jstatusCode = jresString.get("statusCode");

			if((int)jstatusCode == 200){
				JSONObject getSth = jresString.getJSONObject("result");
				String sessionid = (String)getSth.get(BODY_SESSIONID_KEY);
				Log.i(TAG, sessionid);
				mSessionID = sessionid;
				mUserID = email;
				return true;
			} else {
				return false;
			}
		} catch (IOException | JSONException  e) {
			Log.i(TAG, e.toString());
			return false;
		}
	}

	@Override
	public String getSANodeList() {
		if (mSessionID == null)
			return null;

		HTTPRequest httprequest = new HTTPRequest();
		HTTPResponse httpresponse;

		HashMap<String, String> headers = new HashMap<String, String>(); 
		String uri = mServerURL + "/user/getNodeList?session=" + mSessionID;

		try {
			// 1.Handle HTTP request
			headers.put(HEADER_CONTENT_KEY, HEADER_CONTENT_VAL);
			headers.put(HEADER_CLIENTID_KEY, HEADER_CLIENTID_VAL);

			Log.i(TAG, uri);	

			httpresponse = httprequest.get(uri /*URLEncoder.encode(uri,"UTF-8")*/, headers);

			// 2.Handle HTTP response
			Log.i(TAG, "Code = " + httpresponse.getResponseCode());

			String resString = URLDecoder.decode(httpresponse.getString(), "UTF-8");
			Log.i(TAG, "String = " + resString);

			return (String) resString;
		} catch (IOException e) {
			System.out.println(e);
			return null;
		}
	}

	@Override
	public String getSAProfile() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSANodeName(String node) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean registerSANode(String nodeid, String nickname, boolean virtual) {
		if (mSessionID == null)
			return false;

		HTTPRequest httprequest = new HTTPRequest();
		HTTPResponse httpresponse;
		String uri = mServerURL + "/user/registerNode";

		HashMap<String, String> headers = new HashMap<String, String>(); 
		HashMap<String, String> body = new HashMap<String, String>();

		Log.i(TAG, uri);
		try {
			// 1.Handle HTTP request
			headers.put(HEADER_CONTENT_KEY, HEADER_CONTENT_VAL);
			headers.put(HEADER_CLIENTID_KEY, HEADER_CLIENTID_VAL);

			body.put(BODY_SESSIONID_KEY, mSessionID);
			body.put(BODY_NODEID_KEY, nodeid);
			body.put(BODY_NICKNAME_KEY, nickname);
			if (virtual) {
				body.put(BODY_VIRTUAL_KEY, "true");
			}

			httpresponse = httprequest.post(uri, httprequest.propertyString(body), headers);

			// 2.Handle HTTP response
			String resString = URLDecoder.decode(httpresponse.getString(), "UTF-8");
			Log.i(TAG, resString);

			// 3. JSON parse the response
    		JSONObject jresString = new JSONObject(resString);
    		Object jstatusCode = jresString.get("statusCode");

    		if((int)jstatusCode == 200)
    			return true;
    		else 
    			return false;
		} catch (IOException | JSONException  e) {
			Log.i(TAG, e.toString());
			return false;
		}
	}

	@Override
	public boolean unregisterSANode(String nodeid) {
		if (mSessionID == null)
			return false;

		HTTPRequest httprequest = new HTTPRequest();
		HTTPResponse httpresponse;
		String uri = mServerURL + "/user/unregisterNode";

		HashMap<String, String> headers = new HashMap<String, String>(); 
		HashMap<String, String> body = new HashMap<String, String>();

		Log.i(TAG, uri);
		try {
			
			// 1.Handle HTTP request
			headers.put(HEADER_CONTENT_KEY, HEADER_CONTENT_VAL);
			headers.put(HEADER_CLIENTID_KEY, HEADER_CLIENTID_VAL);
			
			body.put(BODY_SESSIONID_KEY, mSessionID);
			body.put(BODY_NODEID_KEY, nodeid);			
			
			httpresponse = httprequest.post(uri, httprequest.propertyString(body), headers);

			// 2.Handle HTTP response
			String resString = URLDecoder.decode(httpresponse.getString(), "UTF-8");
			Log.i(TAG, resString);

			// 3. JSON parse the response
    		JSONObject jresString = new JSONObject(resString);
    		Object jstatusCode = jresString.get("statusCode");
    		
    		if((int)jstatusCode == 200)
    			return true;
    		else 
    			return false;
    		
		} catch (IOException | JSONException  e) {
			Log.i(TAG, e.toString());
			return false;
		}
	}

	@Override
	public String getClientHistory() {
		if (mSessionID == null)
			return null;

		HTTPRequest httprequest = new HTTPRequest();
		HTTPResponse httpresponse;

		HashMap<String, String> headers = new HashMap<String, String>(); 
		String uri = mServerURL + "/log/getHistory?session=" + mSessionID;

		try {
			// 1.Handle HTTP request
			headers.put(HEADER_CONTENT_KEY, HEADER_CONTENT_VAL);
			headers.put(HEADER_CLIENTID_KEY, HEADER_CLIENTID_VAL);

			Log.i(TAG, uri);	
			httpresponse = httprequest.get(uri, headers);

			// 2.Handle HTTP response
			Log.i(TAG, "Code = " + httpresponse.getResponseCode());

			String resString = URLDecoder.decode(httpresponse.getString(), "UTF-8");
			Log.i(TAG, "String = " + resString);

			return (String) resString;
		} catch (IOException e) {
			Log.i(TAG, e.toString());
			return null;
		}
	}

	public String getSessionID() {
		return mSessionID;
	}

	public String getUserID() {
		return mUserID;
	}
}
