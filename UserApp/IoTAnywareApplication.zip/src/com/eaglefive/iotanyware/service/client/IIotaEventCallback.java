package com.eaglefive.iotanyware.service.client;

public interface IIotaEventCallback {
	public void reconnection(boolean result);
	public void message(String category, String id, String method, String payload);
	public void onConnection(boolean result);
}
